<p>Copyright <?php echo date('Y'); ?>, Bike Challenge</p>

<p>This bike project is solely for the creation and development of OOP and PHP and WEB250.</p>
